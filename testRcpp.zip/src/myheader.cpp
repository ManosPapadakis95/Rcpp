
#include <Rcpp.h>
#include "helpers.h"
using namespace Rcpp;

//[[Rcpp::includes("helpers.h")]]

// [[Rcpp::export(name = "A1", cpp_name = "A1")]]
template NumericVector A<NumericVector>(size_t n);


// [[Rcpp::export(name = "A2", cpp_name = "A2")]]
template NumericVector A<NumericVector>(NumericVector x);


// [[Rcpp::export(name = "A3", cpp_name = "A3")]]
NumericVector Test::G();