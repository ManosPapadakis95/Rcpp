#ifndef TEST_RCPP_H
#define TEST_RCPP_H

#include <Rcpp.h>
//#include"testRcpp_RcppExports.h"
using namespace Rcpp;

template<class T>
T A(size_t n){
    return T(n);
}

template<class T>
T A(T x){
    T y = Rcpp::clone(x);
    return y;
}

namespace Test {
    inline NumericVector G(){
        return NumericVector();
    }
}

#endif